USE [Stefan_Proekt_�12]
--Values for engines
INSERT INTO ENGINES (ID, Engine)
VALUES
(1, 'petrol'),
(2, 'diesel'),
(3, 'electric'),
(4, 'hybrid'),
(5, 'plug-in hybrid')

--Values for categories
INSERT INTO CATEGORIES (ID, Category)
VALUES
(1, 'Van'),
(2, 'SUV'),
(3, 'Cabriolet'),
(4, 'Combi'),
(5, 'Coupe'),
(6, 'Minivan'),
(7, 'Pickup Truck'),
(8, 'Sedan'),
(9, 'Stretch Limousine'),
(10, 'Hatchback')

--Values for clients
INSERT INTO CLIENTS (ID, FirstName, LastName, City, GSM)
VALUES
(1, 'Ivan', 'Petrov', 'Sofia', '0888123456'),
(2, 'Maria', 'Ivanova', 'Plovdiv', '0877654321'),
(3, 'Georgi', 'Georgiev', 'Varna', '0899988776'),
(4, 'Elena', 'Dimitrova', 'Burgas', '0888999911'),
(5, 'Nikolay', 'Pavlov', 'Ruse', '0877123456'),
(6, 'Stefani', 'Todorova', 'Stara Zagora', '0899345678'),
(7, 'Petar', 'Stefanov', 'Pleven', '0888555444'),
(8, 'Anna', 'Angelova', 'Sliven', '0876001122'),
(9, 'Vladimir', 'Vladimirov', 'Shumen', '0899001122'),
(10, 'Zhivka', 'Petkova', 'Haskovo', '0888333555')

--Values for cars
INSERT INTO CARS (ID, Brand, Model, Color, [Year], Price, EngineID, CategoryID)
VALUES
(1, 'Tesla', 'Model 3', 'Black', 2020, 35000, 3, 8),
(2, 'Toyota', 'Rav4', 'Blue', 2019, 28000, 1, 2),
(3, 'BMW', 'M4', 'Red', 2021, 60000, 1, 5),
(4, 'Honda', 'Civic', 'Silver', 2018, 22000, 1, 8),
(5, 'Mercedes', 'S-Class', 'White', 2022, 90000, 3, 9),
(6, 'Ford', 'F-150', 'Gray', 2020, 40000, 1, 7),
(7, 'Volkswagen', 'Golf', 'Green', 2017, 25000, 1, 10),
(8, 'Chevrolet', 'Malibu', 'Black', 2019, 30000, 2, 8),
(9, 'Audi', 'A3', 'Silver', 2021, 45000, 1, 8),
(10, 'Nissan', 'Leaf', 'Blue', 2022, 35000, 3, 8),
(11, 'Volkswagen', 'Transporter', 'Red', 2023, 31000, 1, 1),
(12, 'Mercedes', 'E-Class', 'Brown', 2022, 69000, 3, 5)

--Values for sales
INSERT INTO SALES (ID, SaleDate, ClientsID, CarsID)
VALUES
(1, '2021-01-06', 1, 1),
(2, '2022-02-10', 2, 3),
(3, '2023-03-17', 3, 5),
(4, '2017-04-21', 4, 7),
(5, '2022-05-26', 5, 9),
(6, '2020-06-30', 6, 2),
(7, '2018-07-02', 7, 4),
(8, '2023-08-11', 8, 6),
(9, '2024-01-11', 9, 8),
(10, '2023-10-20', 10, 10),
(11, '2024-01-06', 1, 11),
(12, '2023-04-12', 1, 12),
(13, '2021-01-06', 4, 4)


USE [Stefan_Proekt_�12]
CREATE TABLE ENGINES
(
ID int NOT NULL PRIMARY KEY,
Engine varchar(20)
)

CREATE TABLE CATEGORIES
(
ID int NOT NULL PRIMARY KEY,
Category varchar(20)
)

CREATE TABLE CARS
(
ID int NOT NULL PRIMARY KEY,
Brand varchar(20),
Model varchar(30),
Color varchar(20),
[Year] int NOT NULL,
Price money,
EngineID int NOT NULL,
CategoryID int NOT NULL,
CONSTRAINT FK_Engine_Cars
FOREIGN KEY (EngineID)
REFERENCES ENGINES(ID),
CONSTRAINT FK_Category_Cars
FOREIGN KEY (CategoryID)
REFERENCES CATEGORIES(ID)
)

CREATE TABLE CLIENTS
(
ID int NOT NULL PRIMARY KEY,
FirstName varchar(30),
LastName varchar(30),
City varchar(30),
GSM varchar(10)
)

CREATE TABLE SALES
(
ID int NOT NULL PRIMARY KEY,
SaleDate date,
ClientsID int NOT NULL,
CarsID int NOT NULL,
CONSTRAINT FK_Sales_Cars2
FOREIGN KEY (ClientsID)
REFERENCES Clients(ID),
CONSTRAINT FK_Sales_Cars1
FOREIGN KEY (CarsID)
REFERENCES CARS(ID)
)
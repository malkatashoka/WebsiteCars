USE [Stefan_Proekt_�12]
--M. Sales in 2023: Brand, Color, Price
SELECT Brand, Color, Price 
FROM CARS
JOIN SALES ON CARS.ID = SALES.CarsID
WHERE YEAR(SALES.SaleDate) = 2023

--N. CARS BETWEEN 20000 AND 30000: Brand, Category
SELECT Brand, Category 
FROM CARS
JOIN CATEGORIES ON CATEGORIES.ID = CARS.CategoryID
WHERE PRICE BETWEEN 20000 AND 30000

--O.
SELECT Brand, Color, Price 
FROM CARS
JOIN CATEGORIES ON CATEGORIES.ID = CARS.CategoryID
JOIN ENGINES ON ENGINES.ID = CARS.EngineID
WHERE CATEGORIES.Category = 'Van' AND ENGINES.Engine = 'Petrol'

--P.
SELECT FirstName, LastName
FROM CLIENTS
JOIN SALES ON CLIENTS.ID = SALES.ClientsID
JOIN CARS ON CARS.ID = SALES.CarsID
WHERE Brand = 'Mercedes' AND City = 'Sofia'

--Q.
SELECT Brand, Count(Brand) AS [Count]
FROM CARS
GROUP BY Brand

--R.
Select SUM(Price) AS [Total], SALES.SaleDate AS [Date]
FROM CARS
JOIN SALES ON SALES.CarsID = CARS.ID
GROUP BY SALES.SaleDate
-- HAVING COUNT(SALES.SaleDate) > 1 \\ �� �� ����, �� ������
ORDER BY SALES.SaleDate


--S.
SELECT Brand, MAX(Price) AS [MaxPrice]
FROM CARS
GROUP BY Brand

--T.
SELECT COUNT(*) AS [EV Count]
FROM CARS
JOIN ENGINES ON CARS.EngineID = ENGINES.ID
WHERE Engine = 'electric'

--U.
INSERT INTO CARS (ID, Brand, Model, Color, [Year], Price, EngineID, CategoryID)
VALUES
(13, 'Nissan', 'Micra', 'Red', 2002, 8500, 1, 10)



--V.
SELECT FirstName + ' ' + LastName AS [Name], Brand, Price
INTO PURCHASES
FROM CLIENTS
JOIN SALES ON SALES.ClientsID = CLIENTS.ID
JOIN CARS ON CARS.ID = SALES.CarsID

SELECT * FROM PURCHASES

--W. 
UPDATE CARS
SET Price = Price * 1.1
FROM CARS
JOIN ENGINES ON ENGINES.ID = CARS.ENGINEID
WHERE Engine = 'diesel'

--X. Names of a person or a car sorted alphabetically
SELECT Brand, Model 
FROM CARS
UNION
SELECT FirstName, LastName
FROM CLIENTS


